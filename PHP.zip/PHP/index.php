
<?php
// Start the session
session_start();
$c=$_SESSION["check"];
$a=strcmp($c,"admin");
if($a==0){
	$ses="adminhomepage.html";$s="ADMIN";
}
else{
	$ses="userhome.html";$s="USER";
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Chat System</title>


	<link rel="stylesheet" href="style.css" type="text/css" />


	<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
  <style type="text/css">
  	body {/*background-color:lightblue;*/ 
 background-image: url('aaa.jpg');
  background-repeat: no-repeat;
  background-attachment: all;
  background-size: cover;/*https://www.freeiconspng.com/img/3058*/
}
h1{
	text-align:center;
	font-weight: bold;
	color:gold;
	font-size: 50px;
}


.m a:link, a:visited {
	
  
 
  /*padding:  2px 2px;*/
  text-decoration: none;
  display: inline-block;
 
  
}
.m a:hover, a:active {
	
  background-color: gold;
    

}
.m{
	text-align: left;
}
label{color:gold;
	font-weight:40px;
	background-color:black;
	text-align:center;
	font-size:25px; }
	.siglemessage{
	font-size:25px;
	padding:5px;
	border-bottom:1px solid #b3b3b3;
}
form{  
text-align: center;  
margin-right: auto;
margin-left:auto;  
}  

  </style>

</head>

<div class="m">
	<a href="<?= $ses ?>"><img  border="0" src="home.png" width="50" height="50"></a>  &emsp;  &emsp;
	<a href="<?= $ses ?>"><img  border="0" src="back.png" width="50" height="50"></a>
	<h1>CHAT AREA <?= $s?></h1>
	 
	 <form method="post" action="index2.php">
        <input style="height:40px;width:90px;background-color: black;color:gold;text-align: center;" type="submit" name="button1"
                value="CLEAR CHAT" />
     
    </form>

	   

</div>
	

	<div class="centeralised">
	
	<div class="chathistory"></div>

	<div class="chatbox">
		
		<form action="" method="POST">
			<label for="message" >Chat here...</label><br>
			<textarea class="txtarea" id="message" name="message"></textarea>

		</form>

	</div>

	</div>


	

	<script>


		$(document).ready(function(){
			loadChat();
		});


		
		$('#message').keyup(function(e){


			var message = $(this).val();

			if( e.which == 13 ){

				$.post('handlers/ajax.php?action=SendMessage&message='+message, function(response){
					
					loadChat();
					$('#message').val('');

				});

			}

		});



		function loadChat()
		{
			$.post('handlers/ajax.php?action=getChat', function(response){
				
				$('.chathistory').html(response);

			});
		}


		setInterval(function(){
			loadChat();
		}, 2000);

	</script>


</body>
</html>