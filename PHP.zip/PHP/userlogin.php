
<?php
// Start the session
session_start();
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security
$username = mysqli_real_escape_string($link, $_REQUEST['un']); $_SESSION["un"] = $username;$_SESSION["user"] = $username;$_SESSION["check"] = 'user';

$password = mysqli_real_escape_string($link, $_REQUEST['pw']);

?>
<html>
<body>
<?php




$sql = "SELECT * FROM userlogin";
if($result = mysqli_query($link, $sql))
{
if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_array($result))
{  $un=strcmp($username,$row['username']);
    $pw=strcmp($password,$row['password']);
   if(($un==0) and ($pw==0))
   {
   	  include 'userhome.html';break;}


}
if(($un!=0) or ($pw!=0)){
	echo '<script>alert("Username and Password does not matched")</script>';include 'userlogin.html';}
mysqli_free_result($result);
}
}
mysqli_close($link);
?>
</body>
</html>
