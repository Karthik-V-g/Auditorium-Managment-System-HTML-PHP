<?php
// Start the session
session_start();
?>
<html>
<body>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security

$name = mysqli_real_escape_string($link, $_REQUEST['ame']);
$pn = mysqli_real_escape_string($link, $_REQUEST['ph']);
$mail = mysqli_real_escape_string($link, $_REQUEST['mail']);
$purpose = mysqli_real_escape_string($link, $_REQUEST['pur']);
$slot = mysqli_real_escape_string($link, $_REQUEST['choice']);
$date = mysqli_real_escape_string($link, $_REQUEST['dt']);
$amt = mysqli_real_escape_string($link, $_REQUEST['amt']);
$tid = mysqli_real_escape_string($link, $_REQUEST['pid']);




$sql = "SELECT * FROM bookingsuser";
if($result = mysqli_query($link, $sql))
{$res=0;
if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_array($result))
{     $one=strcmp(strval($row['email']),strval($mail));
      $two=strcmp(strval($row['bookingdate']),strval($date));
      if($one==0){
      	echo '<script>alert("Your email has already exists,Try new one")</script>';$res=2; include 'bookingpageuser.html';
           break;}
      if($two==0)
      {  echo '<script>alert("Already Booked Please choose another date")</script>';$res=1; include 'bookingpageuser.html';
           break;
      }



}
mysqli_free_result($result);
}
else
{
echo "No records matching your query were found.";
}
}



if($res==0){

$sql = "INSERT INTO bookingsuser (name,phonenumber,email,purpose,bookingtimeslot,bookingdate,amount,transactionid) VALUES ('$name','$pn','$mail','$purpose','$slot','$date','$amt','$tid')";
if(mysqli_query($link, $sql)){
	
	echo '<script>alert("Booking Successfull")</script>';
 include 'userhome.html';

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

mysqli_close($link);

?>
</body>
</html>
