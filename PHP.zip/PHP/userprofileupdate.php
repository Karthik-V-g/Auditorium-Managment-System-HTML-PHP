<?php
// Start the session
session_start();



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<title>USER</title>
	<link rel="stylesheet" type="text/css" href="ulcss.css">
<style>
body {/*background-color:lightblue;*/ 
 background-image: url('aaa.jpg');
  background-repeat: no-repeat;
  background-attachment: all;
  background-size: cover;/*https://www.freeiconspng.com/img/3058*/
}
input{
	font-weight: bold;
	font-size: 20px;
}



label{
	font-weight: bold;
	font-size: 20px;
	color:white;
	
}
.c{margin-top:100px;
	text-align: center;

}
#h a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

#h a:hover, a:active {
	
 background-color: white;
    color: blue;

}

.c a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

.c a:hover, a:active {
	
 /* background-color: white;*/
    color: blue;

}
.c{
    text-align: center;
    margin-top: 20px;

}
h1{
	text-align:center;
	font-weight: bold;
	color:gold;
	font-size: 50px;
}


.m a:link, a:visited {
	
  
 
  /*padding:  2px 2px;*/
  text-decoration: none;
  display: inline-block;
 
  
}
.m a:hover, a:active {
	
  background-color: gold;
    

}
.m{
	text-align: left;
}
#h{
    text-align: center;
    margin-top: 20px;
    
}

.go{
 
  
  
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: auto;
  transition: 3s;


}
.go:hover{
	transform: scale(1.2);

}
.go{
  margin-top: 50px;
}

table,th {color:gold;font-size: 25px;
  height: 50px;  margin-left: auto;
  margin-right: auto;
}
tr {color:white;font-size: 25px;
  height: 50px;
}
label{
  font-size:25px;color:gold;
}
</style>
</head>
<body >
<div class="m">
	<a href="userhome.html"><img  border="0" src="home.png" width="50" height="50"></a>  &emsp;  &emsp;
	<a href="userhome.html"><img  border="0" src="back.png" width="50" height="50"></a>
	<h1>USER PROFILE UPDATE</h1>
</div>


<?php

$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}

$ses=$_SESSION["un"];
$sql = "SELECT * FROM userprofile WHERE email='$ses'";
if($result = mysqli_query($link, $sql))
{
if(mysqli_num_rows($result) > 0)
{
echo "<table cellspacing='0' cellpadding='2' border='2' CENTRE>";
echo "<tr>";
//echo "<th>id</th>";
echo "<th>FIRST NAME</th>";
echo "<th>LAST NAME</th>";
echo "<th>DOB</th>";
echo "<th>PASSWORD</th>";
echo "<th>GENDER</th>";

echo "<th>ADDRESS</th>";
echo "<th>EMAIL</th>";
echo "<th>PHONE NUMBER</th>";
echo "</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";
//echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['firstname'] . "</td>";
echo "<td>" . $row['lastname'] . "</td>";
echo "<td>" . $row['dob'] . "</td>";
echo "<td>" . $row['password'] . "</td>";
echo "<td>" . $row['gender'] . "</td>";
echo "<td>" . $row['address'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . $row['phonenumber'] . "</td>";
echo "</tr>";
}
echo "</table>";
mysqli_free_result($result);
}
else
{
echo "No records matching your query were found.";
}
}


?>

	
<form  action="userprofileupdate2.php" method="post" >
<div class="c">

 <label for="un">EMAIL:</label> <br>
 <input style="background-color: grey;" type="text" id="email" name="email" value="<?= $ses ?>" readonly> 
 


<br><br>

<label style="color:gold;">CHOOSE ONE AT A TIME TO UPDATE PROFILE:</label><br><br>
<table>
  <tr>
  <td><input type="radio" name="choice" value="firstname" required>  <label>FIRST NAME</label></td>  
  <tr>    
  <td><input type="radio"  name="choice" value="lastname"><label>LAST NAME</label></td></tr>
  <tr><td>
  <input type="radio"  name="choice" value="dob">&emsp;&emsp;&emsp;&emsp;<label>  DOB </label>
   </td></tr><tr>
   <td><input type="radio" name="choice" value="password"> <label>PASSWORD</label></td> </tr><tr>     
  <td><input type="radio"  name="choice" value="gender">&emsp;&emsp;<label id="l">GENDER</label>
      </td><tr>
<td>  <input type="radio"  name="choice" value="address">&emsp;&emsp;<label>ADDRESS</label>
  </td></tr><tr><td>
   <input type="radio" name="choice" value="phonenumber"><label>PHONE NUMBER</label>  </td></tr>    
  </tr></table>
  <br><br>




  <label for="pw">ENTER NEW DETAIL:<br>[note:please use (YYYY-MM-DD) format for dob]</label> <br>
  <input  type="text" id="val" name="val" required>


<br><br>


  <input type="submit" value="UPDATE">   &emsp;
  <input type="reset" value="RESET">

</div>
</form>
<div id="h">

	
	<!-- <a href="home.html">Go Back</a> -->

</div>
 <img class="go" src="1.png"alt="logo"> 

</body>
</html>