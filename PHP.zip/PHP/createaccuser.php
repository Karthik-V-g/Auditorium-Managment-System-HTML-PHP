
<html>
<body>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security

$fname = mysqli_real_escape_string($link, $_REQUEST['fname']);
$lname= mysqli_real_escape_string($link, $_REQUEST['lname']);
$dob = mysqli_real_escape_string($link, $_REQUEST['dob']);
$password = mysqli_real_escape_string($link, $_REQUEST['pw']);
$gender= mysqli_real_escape_string($link, $_REQUEST['choice']);
$address = mysqli_real_escape_string($link, $_REQUEST['add']);
$email = mysqli_real_escape_string($link, $_REQUEST['mail']);
$phonenumber= mysqli_real_escape_string($link, $_REQUEST['ph']);




$sql = "SELECT * FROM userprofile";
if($result = mysqli_query($link, $sql))
{$res=0;
if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_array($result))
{     $one=strcmp(strval($row['email']),strval($email));
      
      if($one==0){
      	echo '<script>alert("Your email has already exists,Try new one")</script>';$res=2; include 'createaccuser.html';
           break;}
      



}
mysqli_free_result($result);
}
else
{
echo "No records matching your query were found.";
}
}



if($res==0){

$sql = "INSERT INTO userprofile (firstname,lastname,dob,password,gender,address,email,phonenumber) VALUES ('$fname','$lname','$dob','$password','$gender','$address','$email','$phonenumber')";
if(mysqli_query($link, $sql)){
	
	echo '<script>alert("Profile Created Successfully")</script>';
 

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}


$sql = "INSERT INTO userlogin (username,password) VALUES ('$email','$password')";
if(mysqli_query($link, $sql)){
  
  echo '<script>alert("Use email and password for login")</script>';
 include 'userlogin.html';

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

mysqli_close($link);

?>
</body>
</html>
