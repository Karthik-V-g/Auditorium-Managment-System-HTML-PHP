<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security

$mail = mysqli_real_escape_string($link, $_REQUEST['mail']);
$sql = "INSERT INTO cancellist (email) VALUES ('$mail')";
if(mysqli_query($link, $sql)){
  
  echo '<script>alert("Request Sent")</script>';
 include 'userviewhistory.php';

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);include 'userviewhistory.php';
}
mysqli_close($link);
?>

</body>
</html>