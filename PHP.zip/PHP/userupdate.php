<?php
// Start the session
session_start();


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security




$sql = "SELECT * FROM bookingsuser WHERE email=$_SESSION["un"]";
if($result = mysqli_query($link, $sql))
{
if(mysqli_num_rows($result) > 0)
{
echo "<table>";
echo "<tr>";
//echo "<th>id</th>";
echo "<th>NAME</th>";
echo "<th>PHONE NUMBER</th>";
echo "<th>EMAIL</th>";
echo "<th>PURPOSE</th>";
echo "<th>BOOKING TIME SLOT</th>";

echo "<th>BOOKING DATE</th>";
echo "<th>AMOUNT</th>";
echo "<th>TRANSACTION ID</th>";
echo "</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";
//echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['phonenumber'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . $row['purpose'] . "</td>";
echo "<td>" . $row['bookingtimeslot'] . "</td>";
echo "<td>" . $row['bookingdate'] . "</td>";
echo "<td>" . $row['amount'] . "</td>";
echo "<td>" . $row['transactionid'] . "</td>";
echo "</tr>";
}
echo "</table>";
mysqli_free_result($result);
}
else
{
echo "No records matching your query were found.";
}
}
mysqli_close($link);


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<title>ADMIN PROFILE UPDATE</title>
	<link rel="stylesheet" type="text/css" href="ulcss.css">
<style>
body {/*background-color:lightblue;*/ 
 background-image: url('aaa.jpg');
  background-repeat: no-repeat;
  background-attachment: all;
  background-size: cover;/*https://www.freeiconspng.com/img/3058*/
}
input{
	font-weight: bold;
	font-size: 20px;
}



label{
	font-weight: bold;
	font-size: 20px;
	color:white;
	
}
.c{margin-top:100px;
	text-align: center;

}
#h a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

#h a:hover, a:active {
	
 background-color: white;
    color: blue;

}

.c a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

.c a:hover, a:active {
	
 /* background-color: white;*/
    color: blue;

}
.c{
    text-align: center;
    margin-top: 20px;

}
h1{
	text-align:center;
	font-weight: bold;
	color:gold;
	font-size: 50px;
}


.m a:link, a:visited {
	
  
 
  /*padding:  2px 2px;*/
  text-decoration: none;
  display: inline-block;
 
  
}
.m a:hover, a:active {
	
  background-color: gold;
    

}
.m{
	text-align: left;
}
#h{
    text-align: center;
    margin-top: 20px;
    
}

.go{
 
  
  
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: auto;
  transition: 3s;


}
.go:hover{
	transform: scale(1.2);

}
.go{
  margin-top: 50px;
}
</style>
</head>
<body >
<div class="m">
	<a href="home.html"><img  border="0" src="home.png" width="50" height="50"></a>  &emsp;  &emsp;
	<a href="adminlogin.html"><img  border="0" src="back.png" width="50" height="50"></a>
	<h1>USER PROFILE UPDATE</h1>
</div>

	
<form  action="" >
<div class="c">

 <label for="un">ENTER EMAIL(FOR CANCEL BOOKING):</label> 
 <input  type="text" id="email" name="email" > 
 


<br><br>

    

  <input type="submit" value="Cancel">   &emsp;
  <input type="reset" value="RESET">

</div>
</form>
<div id="h">

	
	<!-- <a href="home.html">Go Back</a> -->

</div>
 <img class="go" src="1.png"alt="logo"> 

</body>
</html>