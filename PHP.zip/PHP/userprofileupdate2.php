

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
$ses=mysqli_real_escape_string($link, $_REQUEST['email']);
$choice = mysqli_real_escape_string($link, $_REQUEST['choice']);
$val = mysqli_real_escape_string($link, $_REQUEST['val']);

$a=0;
switch ($choice) {
  case "firstname":
    $sql = "UPDATE userprofile SET firstname='$val' WHERE email='$ses'";
    break;
  case "lastname":
    $sql = "UPDATE userprofile SET lastname='$val' WHERE email='$ses'";
    break;
  case "dob":
    $sql = "UPDATE userprofile SET dob='$val' WHERE email='$ses'";
    break;
  case "password":
    $sql = "UPDATE userprofile SET password='$val' WHERE email='$ses'";
    $sql1 = "UPDATE userlogin SET password='$val' WHERE username='$ses'";

    $a=1;
    break;
  case "gender":
    $sql = "UPDATE userprofile SET gender='$val' WHERE email='$ses'";
    break;
  case "address":
    $sql = "UPDATE userprofile SET address='$val' WHERE email='$ses'";
    break;
  case "phonenumber":
    $sql = "UPDATE userprofile SET phonenumber='$val' WHERE email='$ses'";
    break;
  
    
}
	
if(mysqli_query($link, $sql)){
	
	if($a==1){
		mysqli_query($link, $sql1);
        }
	echo '<script>alert("Updated Successfull")</script>';
 include "userprofileupdate.php";

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}


	?>

</body>
</html>