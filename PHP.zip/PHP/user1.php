<?php

	
	session_start();

	$_SESSION['user'] = 'Faisal Imtiaz';


?>