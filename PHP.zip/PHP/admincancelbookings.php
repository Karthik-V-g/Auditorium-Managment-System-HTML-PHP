

<!DOCTYPE html>
<html>
<head>

  <title></title>
  <link rel="stylesheet" type="text/css" href="ulcss.css">
<style>
body {/*background-color:lightblue;*/ 
 background-image: url('aaa.jpg');
  background-repeat: no-repeat;
  background-attachment: all;
  background-size: cover;/*https://www.freeiconspng.com/img/3058*/
}
input{
  font-weight: bold;
  font-size: 20px;
}



label{
  font-weight: bold;
  font-size: 20px;
  color:white;
  
}
.c{margin-top:100px;
  text-align: center;

}
#h a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

#h a:hover, a:active {
  
 background-color: white;
    color: blue;

}

.c a:link, a:visited {
  background-color:black ;
  color: white;
  padding:auto;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  
}

.c a:hover, a:active {
  
 /* background-color: white;*/
    color: blue;

}
.c{
    text-align: center;
    margin-top: 20px;

}
h1{
  text-align:center;
  font-weight: bold;
  color:lightgreen;
  font-size: 50px;
}


.m a:link, a:visited {
  
  
 
  /*padding:  2px 2px;*/
  text-decoration: none;
  display: inline-block;
 
  
}
.m a:hover, a:active {
  
  background-color: gold;
    

}
.m{
  text-align: left;
}
#h{
    text-align: center;
    margin-top: 20px;
    
}

.go{
 
  
  
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: auto;
  transition: 3s;


}
.go:hover{
  transform: scale(1.2);

}
.go{
  margin-top: 50px;
}
table,th {color:gold;font-size: 25px;
  height: 50px;  margin-left: auto;
  margin-right: auto;
}
tr {color:white;font-size: 25px;
  height: 50px;
}
label{
  font-size:25px;color:gold;
}
</style>
</head>
<body >
<div class="m">
  <a href="adminhomepage.html"><img  border="0" src="home.png" width="50" height="50"></a>  &emsp;  &emsp;
  <a href="adminhomepage.html"><img  border="0" src="back.png" width="50" height="50"></a>
  <h1>ADMIN-CANCEL BOOKINGS</h1>
</div>
<br><br>

<form  method="post" action="admincancelbookings1.php" >
<div class="c">

 <label for="un">DELETE BOOKING BY EMAIL/USERNAME:</label> <br><br>
 <input  type="email" id="mail" name="mail"> 
 


<br><br>

    

  <input type="submit" value="SUBMIT" name="sub">   &emsp;
  <input type="reset" value="RESET">

</div>
</form>
<br>
<h2 style="color:white;text-align: center;">Below is the list of users who wants to cancel their bookings</h2>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security

  




$sql1="SELECT * FROM cancellist";



if($result1 = mysqli_query($link, $sql1))
{
if(mysqli_num_rows($result1) > 0)
{ echo "<table cellspacing='0' cellpadding='2' border='2' CENTRE>";
echo "<tr>";
//echo "<th>id</th>";
echo "<th>NAME</th>";
echo "<th>PHONE NUMBER</th>";
echo "<th>EMAIL</th>";
echo "<th>PURPOSE</th>";
echo "<th>BOOKING TIME SLOT</th>";

echo "<th>BOOKING DATE</th>";
echo "<th>AMOUNT</th>";
echo "<th>TRANSACTION ID</th>";
echo "</tr>";
while($row1 = mysqli_fetch_array($result1))
{ $ans=$row1['email'];

   $sql = "SELECT * FROM bookingsuser WHERE email='$ans'";

if($result = mysqli_query($link, $sql))
{
if(mysqli_num_rows($result) > 0)
{


while($row = mysqli_fetch_array($result))
{ 
echo "<tr>";
//echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['phonenumber'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . $row['purpose'] . "</td>";
echo "<td>" . $row['bookingtimeslot'] . "</td>";
echo "<td>" . $row['bookingdate'] . "</td>";
echo "<td>" . $row['amount'] . "</td>";
echo "<td>" . $row['transactionid'] . "</td>";
echo "</tr>";

}


}
else
{
echo '<h1>No Bookings are there.</h1>';
}
}



}

echo "</table>";
mysqli_free_result($result);mysqli_free_result($result1);
}
else
{
echo '<h1>No Bookings are there.</h1>';
}
}







?>

  <br><br>


<div id="h">

  
  <!-- <a href="home.html">Go Back</a> -->

</div>
 <img class="go" src="1.png"alt="logo"> 

</body>
</html>