<?php

	$dbhost = "localhost:3308";
	$dbname = "SELAB";
	$dbuser = "root";
	$dbpass = "";


	try{
		$db = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
	}catch(PDOException $e){
		echo $e->getMessage();
	}

	



?>