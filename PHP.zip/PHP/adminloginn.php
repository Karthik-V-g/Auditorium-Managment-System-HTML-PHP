<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<title>ADMIN LOGIN</title>
	<link rel="stylesheet" type="text/css" href="ulcss.css">
</head>
<body >
<div class="m">
	<a href="home.html"><img  border="0" src="home.png" width="50" height="50"></a>  &emsp;  &emsp;
	<a href="home.html"><img  border="0" src="back.png" width="50" height="50"></a>
	<h1>ADMIN LOGIN</h1>
</div>

	
<form method="post" action="adminlogin.php" >
<div class="c">

 <label for="un">USERNAME:</label> 
 <input style="margin-right: 140px;margin-top: 50px;"  type="text" id="un" name="un" > 

 


<br><br>

  <label for="pw">PASSWORD:</label> 
  <input style="margin-right: 0px;"  type="text" id="pw" name="pw" required>
  <a href="forgetpasswordadmin.html">forgot password</a>


<br><br>


  <input type="submit" value="LOGIN" required>   &emsp;
  <input type="reset" value="RESET">

</div>
</form>
<div id="h">

	<a href="createaccadmin.html">Create new account</a>
	<!-- <a href="home.html">Go Back</a> -->

</div>
 <img class="go" src="1.png"alt="logo"> 

</body>
</html>