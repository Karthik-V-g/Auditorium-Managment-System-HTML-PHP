
<html>
<body>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Escape user inputs for security

$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$pn= mysqli_real_escape_string($link, $_REQUEST['pn']);





$sql = "SELECT * FROM userprofile WHERE email='$email'";
if($result = mysqli_query($link, $sql))
{
if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_array($result))
{     $one=strval($row['phonenumber']);$res=strcmp($pn,$one);
   if($res==0){
    $pwd=$row['password'];$p="Your Password is ";$pwd=$p.$pwd;
      
      
      echo "<script type='text/javascript'>alert('$pwd')</script>";
      include 'userlogin.html';}
      	else
      	
      	{
      		echo '<script >alert("Your phone number is wrong")</script>';include 'forgetpassworduser.html';
      	
      	}
      



}
mysqli_free_result($result);
}
else
{
echo '<script>alert("Your email is wrong")</script>';include 'forgetpassworduser.html';
      
}
}



mysqli_close($link);

?>
</body>
</html>
