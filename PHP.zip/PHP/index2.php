<?php
          
 session_start();
 error_reporting(0);
ini_set('display_errors', 0);


         $ccc=$_SESSION["check"];$d=strcmp($ccc,"admin");$dd=strcmp($ccc,"user");
        if(isset($_POST['button1']) and $d==0) {
            /* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "DELETE FROM chat";
if(mysqli_query($link, $sql)){
	
	echo '<script>alert("Chat Deleted Successfull")</script>';
 include 'index.php';$d==1;

} else{

echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

        }
        else if(isset($_POST['button1']) and $dd==0){
                  echo '<script>alert("Sorry, user cannot delete chat")</script>';include 'index.php';$dd==1;
        }
       
    ?>
      