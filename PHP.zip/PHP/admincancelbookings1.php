<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3308", "root", "", "SELAB");
// Check connection
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}

  $mail =mysqli_real_escape_string($link, $_REQUEST['mail']);;
  $sql2 = "DELETE FROM bookingsuser WHERE email='$mail'";
$sql3 = "DELETE FROM cancellist WHERE email='$mail'";
if(mysqli_query($link, $sql2) and mysqli_query($link, $sql3))
{echo '<script>alert("Booking Cancelled Successfully")</script>';
 include 'admincancelbookings.php';
}
else
{  echo '<script>alert("Booking not cancelled")</script>';
 include 'admincancelbookings.php';
} //get input text
  
  ?>